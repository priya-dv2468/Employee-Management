package com.quest.ems.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.quest.ems.dto.UserRegistrationDto;
import com.quest.ems.model.User;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
